<?php

require_once __DIR__.'/router.php';

// any('/', 'Example/index.php');
// any('/about', 'Example/about-us.php');

// any('/','article-crm/index');
// any('/dashboard','article-crm/dashboard');
// any('/create-post','article-crm/create-post');
// any('/dashboard/$slug','article-crm/index');
// any('/login','article-crm/auth-login');
// any('/sign-up','article-crm/auth-sign-up');

// any('/', 'NIT/indexx');
// any('/about', 'NIT/about');
// any('/contact', 'NIT/contact');
// any('/service', 'NIT/service');
// any('/blog-single', 'NIT/blog-single');
// any('/blog', 'NIT/blog');

any('/','TEST4/index');
any('/config','TEST4/config');
any('/generate_data','TEST4/generate_data');
