<?php
// generate_data.php
header('Content-Type: application/json');
$config = include('config.php');

function random_metric($type) {
    switch($type) {
        case 'cpu': return rand(10, 95);
        case 'memory': return rand(20, 90);
        case 'disk': return rand(10, 95);
        case 'network': return rand(5, 100);
    }
    return 0;
}

function random_event($services) {
    $chance = rand(1, 100);
    if ($chance <= 15) { // 15% chance of incident
        $service = $services[array_rand($services)];
        $types = ['CPU Spike','Memory Leak','Network Latency','Service Down'];
        return [
            'service' => $service,
            'event' => $types[array_rand($types)],
            'severity' => ['Warning','Critical'][rand(0,1)],
            'timestamp' => time()
        ];
    }
    return null;
}

// Generate metrics
$metrics = [];
foreach($config['services'] as $svc){
    $metrics[$svc] = [
        'cpu' => random_metric('cpu'),
        'memory' => random_metric('memory'),
        'disk' => random_metric('disk'),
        'network' => random_metric('network'),
        'timestamp' => time()
    ];
}

// Generate events
$event = random_event($config['services']);

echo json_encode(['metrics'=>$metrics, 'event'=>$event]);
