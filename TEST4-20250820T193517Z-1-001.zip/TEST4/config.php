<?php
// config.php

return [
    'bhom_endpoint' => 'https://bhom-endpoint/api/ingest', // Replace with real endpoint
    'simulation_interval_ms' => 2000, // how often data is generated
    'services' => [
        'Database Server',
        'Web Server',
        'Payment Gateway',
        'Network Router'
    ],
];
