<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ITOps Simulation Dashboard</title>
<link rel="stylesheet" href="/Test4/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h1>ITOps Simulation Dashboard</h1>

<!-- Charts go here -->
<div id="charts" style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; height:600px;"></div>

<!-- Events go here -->
<h2>Recent Events</h2>
<div id="events-container" style="max-height:200px; overflow-y:auto;">
  <ul id="event-list"></ul>
</div>
<script src="/Test4/dashboard.js"></script>
</body>
</html>
