# ITOps Simulator

## Setup
1. Copy project to PHP server (XAMPP, MAMP, WAMP, or live server).
2. Configure BHOM endpoint in `config.php` (optional).
3. Open `index.php` in browser.
4. The dashboard will update every 2 seconds with synthetic metrics & events.

## Features
- Real-time metrics simulation (CPU, Memory, Disk, Network)
- Random events with severity
- Dashboard with charts & event feed
- BHOM ingestion-ready JSON output
