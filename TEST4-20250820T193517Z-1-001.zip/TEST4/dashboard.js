const services = ["Payment Gateway","Network Router"];
let charts = {};
let eventList = document.getElementById('event-list');

// Initialize charts
services.forEach(service=>{
    const canvas = document.createElement('canvas');
    document.getElementById('charts').appendChild(canvas);
    charts[service] = new Chart(canvas.getContext('2d'), {
        type: 'line',
        data: { labels: [], datasets: [
            { label:'CPU', data:[], borderColor:'red', fill:false },
            { label:'Memory', data:[], borderColor:'blue', fill:false },
            { label:'Disk', data:[], borderColor:'green', fill:false },
            { label:'Network', data:[], borderColor:'orange', fill:false }
        ]},
        options: { responsive:true, maintainAspectRatio:false }
    });
});

// Fetch data repeatedly
setInterval(()=>{
    fetch('/generate_data')
    .then(res=>res.json())
    .then(data=>{
        console.log(data);
        
        const timestamp = new Date(data.metrics[services[0]].timestamp*1000).toLocaleTimeString();
        services.forEach(svc=>{
            let chart = charts[svc];
            if(chart.data.labels.length > 20) {
                chart.data.labels.shift();
                chart.data.datasets.forEach(ds=>ds.data.shift());
            }
            chart.data.labels.push(timestamp);
            chart.data.datasets[0].data.push(data.metrics[svc].cpu);
            chart.data.datasets[1].data.push(data.metrics[svc].memory);
            chart.data.datasets[2].data.push(data.metrics[svc].disk);
            chart.data.datasets[3].data.push(data.metrics[svc].network);
            chart.update();
        });

        // Display events
if (data.event) {
    const li = document.createElement('li');
    li.textContent = `[${new Date(data.event.timestamp*1000).toLocaleTimeString()}] ${data.event.service} - ${data.event.event} (${data.event.severity})`;
    document.getElementById('event-list').prepend(li);

    if (eventList.children.length > 10) {
        eventList.removeChild(eventList.lastChild);
    }
}

    });
}, 2000);
